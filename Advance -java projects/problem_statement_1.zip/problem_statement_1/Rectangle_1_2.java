package com.problem_statement_1;

import java.util.Scanner;

public class Rectangle_1_2 {
	int length; 
    int breadth; 
    int area; 
    int perimeter;

    void input() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the length of rectangle: ");
        length = sc.nextInt();
        System.out.print("Enter the breadth of rectangle: ");
        breadth = sc.nextInt();
    }

    void calculate() {
        area = length * breadth;
        perimeter = 2 * (length + breadth);
    }

    void display() {
        System.out.println("Area of Rectangle = " + area);
        System.out.println("Perimeter of Rectangle = " + perimeter);
    }

    public static void main(String args[]) {
    	Rectangle_1_2 obj = new Rectangle_1_2();
        obj.input();
        obj.calculate();
        obj.display();
    }
}
